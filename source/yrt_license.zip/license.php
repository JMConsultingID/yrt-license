<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "ardn6629_yrt_l1c3ns3_ea"; // Make sure this is correct
$password = "ebFYGi=cof%_"; // Make sure this is correct
$dbname = "ardn6629_yrt_l1c3ns3_ea";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $license_key = $_POST['license_key'];
    $account_id = $_POST['account_id'];
    $sql = "SELECT * FROM yrt_ea_license WHERE license_key='$license_key' AND account_id='$account_id' AND status='active'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "valid";
    } else {
        echo "invalid";
    }
}
$conn->close();
?>